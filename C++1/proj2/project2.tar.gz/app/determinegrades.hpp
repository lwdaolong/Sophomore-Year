//determinegrades.hpp
#ifndef DETERMINEGRADES_HPP
#define DETERMINEGRADES_HPP

#include <iostream>
#include <string>
#include "stringhelper.hpp"
#include "artifacts.hpp"
#include "studentutil.hpp"
#include "arrayfunctionality.hpp"

void processCutPoints(int numcutpoints, int numstudents, student *s);



#endif

