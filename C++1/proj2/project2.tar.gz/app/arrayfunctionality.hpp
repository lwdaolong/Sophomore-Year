//arrayfunctionality.hpp
#ifndef ARRAYFUNCTIONALITY_HPP
#define ARRAYFUNCTIONALITY_HPP

#include <iostream>

int sumarraystatic(int arr[],int size);
int sumarraydynamic(int* arr, int size);
void printarraystatic(int arr[],int size);
void printarraystatic(double arr[],int size);
void printarraydynamic(int* arr, int size);


#endif

