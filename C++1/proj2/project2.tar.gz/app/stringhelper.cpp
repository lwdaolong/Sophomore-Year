//stringhelper.cpp
#include "stringhelper.hpp"

void resolveNewLineChar(){
    std::string temp;
    std::getline(std::cin,temp);
}

void resolveSingleChar(){
    char temp;
    std::cin>>temp;
}