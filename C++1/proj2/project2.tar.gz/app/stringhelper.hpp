//stringhelper.hpp
#ifndef STRINGHELPER_HPP
#define STRINGHELPER_HPP

#include <iostream>
#include <string>

void resolveNewLineChar();
void resolveSingleChar();



#endif