//rawscoreutil.hpp
#ifndef RAWSCOREUTIL_HPP
#define RAWSCOREUTIL_HPP

#include <iostream>
#include <string>
#include "stringhelper.hpp"
#include "artifacts.hpp"
#include "studentutil.hpp"

void processRawScores(int numscores, int numstudents, student *s, artifact *a);



#endif

